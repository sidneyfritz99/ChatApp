/**
 * Author: Sidney Fritz, Matthias Hoffman
 */

#include "Client.h"
#include "Application.h"
#include "vusocket.h"


void Client::tick() {
    //ask the user for input such as a message or command
    std::cout << "Input?\n";
    std::string in;
    
    char buffer[1024];
    std::string send_val;
    char first;
    std::getline(std::cin, in);
    std::cout << "    sdsd " << in << std::endl;
    ssize_t in_len = in.length();
    if(in_len > 0){
        first = in.at(0);
    }
    char at = '@';
    if(in == "!who"){
        std::string command = "WHO\n";
        send_val = command;
    }
    else if(first == at){
        std::cout << "found";
        std::string command = "SEND ";
        std::string message;
        in.erase(0, 1);
        message = command + in + "\n";
        send_val = message;
    }
    const char *buf = send_val.c_str();
    if ((send(sockFR, buf, sizeof(buf), 0)) < 0) {
        fprintf(stderr, "error in socket send\n");
    }
    else{
        std::cout << "";
    }
    std::string empty = "";
    for(int i = 0; i < 1; i++){
        //ssize_t retval = recv(sockFR, buffer, sizeof(buffer), 0);
        //std::cout << buffer << "\n";
        break;
        //if (retval <= 0) {
        //    std::cout << "error" << "\n";
        //} else {
        //    std::cout << buffer << "\n";
        //}
    }
    memset(&buf, 0, sizeof(buf));
    memset(&buffer, 0, sizeof(buffer));
    std::cin.clear();
}

int Client::readFromStdin(){
    std::string command;
    std::cin>>command;
    if(command == "!quit"){
        return -1;
    }else{
        return 1;
    }
}

int Client::readFromSocket(){
    return 1;
}

void Client::closeSocket(){
    sock_close(sock);
    sock_quit();
}

void Client::createSocketAndLogIn() {
    sock_init();
    int status;
    struct addrinfo hints;
    struct addrinfo *servinfo;  // will point to the results

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_protocol = IPPROTO_TCP;     // fill in my IP for me

    if ((status = getaddrinfo("52.58.97.202", "5378", &hints, &servinfo)) > 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(1);
    } else {
        std::cout << "Connection Success\n";
        bool in_use = true;
        while (in_use) {
            sockFR = socket(servinfo->ai_family, servinfo->ai_socktype, 0);
            if (connect(sockFR, servinfo->ai_addr, servinfo->ai_addrlen) < 0) {
                std::cout << "error";
            }
            std::string user;
            std::cout << "Please enter a username:" << std::endl;
            std::getline(std::cin, user);

            std::string message = "HELLO-FROM " + user + "\n";

            const char *buffer = message.c_str();

            if ((send(sockFR, buffer, strlen(buffer), 0)) < 0) {
                fprintf(stderr, "error in socket send\n");
            }

            char buf[1024];

            ssize_t retval = recv(sockFR, buf, sizeof(buf), 0);
            if (retval <= 0) {
                std::cout << "error" << "\n";;
            } else {
                std::cout << buf << "\n";
                std::string empty = "";
                const char *buffer = empty.c_str();
                const char *buf = empty.c_str();
                if((std::string)buf != "IN-USE\n"){
                    break;
                }
                else if((std::string)buf == "IN_USE\n"){
                    std::cout << "That username is in use";
                }
                else if((std::string)buf == "BUSY\n"){
                    std::cout << "Server Busy";
                }

            }
            memset(&buf, 0, sizeof(buf));
            memset(&buffer, 0, sizeof(buffer));
            std::cin.ignore();
            std::cin.clear();
        }
        freeaddrinfo(servinfo); // free the linked-list
    }

}
