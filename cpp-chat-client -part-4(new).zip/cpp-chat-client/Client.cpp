/**
 * Author: Sidney Fritz, Matthias Hoffman
 */

#include "Client.h"
#include "Application.h"
#include "vusocket.h"
#include <iostream>
#include <string>


void Client::tick() {
    if(stdinBuffer.hasLine()){
        std::string send_val;
        std::string line;
        line = stdinBuffer.readLine();
        if(line.length() > 0){
            if(line.at(0) == '!'){
                if(line == "!who\n"){
                    send_val = "WHO\n";
                }
            }
            else if(line.at(0) == '@'){
                std::string command = "SEND ";
                line.replace(0, 1, "") + "\n";
                send_val = command + line;
            }
            if(send_val.length() > 0){
                send(sockFR, send_val.c_str(), send_val.length(), 0);
                std::cout << "Sent: " << send_val;
            }
            else{
                std::cout << "Invalid Input" << std::endl << "> Press Enter to Continue" << std::endl;
            }
        }
    }
    if(socketBuffer.hasLine()){
        std::string line;
        line = socketBuffer.readLine();
        if(line.length() > 0){
            std::string sendOk = "SEND-OK\n";
            std::string whoOk = "WHO-OK";
            std::string unknown  = "UNKNOWN";
            std::string delivery = "DELIVERY";
            std::string badReqHdr = "BAD-RQST-HDR\n";
            std::string badReqBdy = "BAD-RQST-BODY\n";

            if(line == sendOk){
                std::cout << "Message Sent" << std::endl;
                reqIn = true;
            }
            if((line.find(whoOk))!=std::string::npos){
                line.replace(0, 7, "");
                std::string userlist;
                userlist = "List of online users: " + line;
                std::cout << userlist;
                reqIn = true;
            }
            if((line.find(unknown))!=std::string::npos){
                std::cout << "Message not sent, destination user not online." << std::endl;
                reqIn = true;
            }
            if(line == badReqHdr){
                std::cout << "Error in message header." << std::endl;
                reqIn = true;
            }
            if(line == badReqBdy){
                std::cout << "Error in message body." << std::endl;
                reqIn = true;
            }
            if((line.find(delivery))!=std::string::npos){
                line.replace(0, 9, "");
                size_t userEnd;
                userEnd = line.find_first_of(" ");
                line.insert(userEnd, ":");
                std::cout << line;
                if(reqIn){
                    std::cout << "Input?" << std::endl;
                }
            }
        }
    }
}

int Client::readFromStdin(){
    if(!stdinBuffer.hasLine() && reqIn){
        //ask the user for input such as a message or command
        std::cout << "Input?" << std::endl;
        char in[4096];
        std::string in_string;
        std::getline(std::cin, in_string);
        if(in_string.length() > 0){
            reqIn = false;
            in_string = in_string + '\n';
            if(in_string == "!quit\n"){
                return -1;
            }
            stdinBuffer.writeChars(in_string.c_str(), in_string.length());
            std::cin.clear();
            memset(&in, 0, sizeof(in));
            return 1;
        }
    }
    return 1;
}

int Client::readFromSocket(){
    char rec_buffer[4096];
    ssize_t retval = recv(sockFR, rec_buffer, sizeof(rec_buffer), 0);
    int x = (unsigned)strlen(rec_buffer);
    if(retval){
        socketBuffer.writeChars(rec_buffer, x);
    }
    memset(&rec_buffer, 0, sizeof(rec_buffer));
    return 1;
}

void Client::closeSocket(){
    sock_close(sock);
    sock_quit();
}

void Client::createSocketAndLogIn() {
    sock_init();
    int status;
    struct addrinfo hints;
    struct addrinfo *servinfo;  // will point to the results

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_protocol = IPPROTO_TCP;     // fill in my IP for me

    if ((status = getaddrinfo("52.58.97.202", "5378", &hints, &servinfo)) > 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(1);
    } else {
        std::cout << "Connection Success\n";
        bool in_use = true;
        while (in_use) {
            sockFR = socket(servinfo->ai_family, servinfo->ai_socktype, 0);
            if (connect(sockFR, servinfo->ai_addr, servinfo->ai_addrlen) < 0) {
                std::cout << "error";
            }
            std::string user;
            std::cout << "Please enter a username:" << std::endl;
            std::getline(std::cin, user);
            reqIn = true;
            std::string message = "HELLO-FROM " + user + "\n";

            const char *buffer = message.c_str();

            if ((send(sockFR, buffer, strlen(buffer), 0)) < 0) {
                fprintf(stderr, "error in socket send\n");
            }

            char buf[1024];

            ssize_t retval = recv(sockFR, buf, sizeof(buf), 0);
            if (retval <= 0) {
                std::cout << "error" << "\n";
            } else {
                std::cout << buf;
                if((std::string)buf != "IN-USE\n" && (std::string)buf != "BUSY\n"){
                    break;
                }
                else if((std::string)buf == "IN_USE\n"){
                    std::cout << "That username is in use";
                }
                else if((std::string)buf == "BUSY\n"){
                    std::cout << "Server Busy";
                }

            }
            memset(&buf, 0, sizeof(buf));
            memset(&buffer, 0, sizeof(buffer));
            std::cin.clear();
            std::cin.sync();
        }
        freeaddrinfo(servinfo); // free the linked-list
    }

}
