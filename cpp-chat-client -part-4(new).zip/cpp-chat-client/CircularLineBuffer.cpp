/**
 * Author: Sidney Fritz & Matthias
 */

#include "CircularLineBuffer.h"
#include <iostream>


int CircularLineBuffer::freeSpace(){
    return bufferSize - count;
};

bool CircularLineBuffer::isFull(){
    return count == bufferSize;
};

bool CircularLineBuffer::isEmpty(){
    return count == start;
};

int CircularLineBuffer::nextFreeIndex(){
    if(!isFull()){
        return count;
    }
    else{
        return 0;
    }
};

int CircularLineBuffer::findNewline(){
    if(isEmpty()){
        return -1;
    }
    int i = start;
    while(!isEmpty()){
        if(i == bufferSize){
            i = 0;
        }
        if(i == count){
            return -1;
        }
        if(buffer[i] == '\n'){
            return i;
        }
        i++;
    };
    return 0;
};
bool CircularLineBuffer::hasLine(){
    int line_index = findNewline();
    if(line_index == -1){
        return false;
    }
    else{
        return true;
    }
};
bool CircularLineBuffer::writeChars(const char *chars, size_t nchars){
    mtx.lock();
    int j = 0;
    while(j < nchars){
        if(count == bufferSize){
            count = 0;
        }
        else{
            buffer[count] = chars[j];
            j++;
            count++;
        }
    }
    mtx.unlock();
    return true;
};

std::string CircularLineBuffer::readLine(){
    mtx.lock();
    std::string word = "";
    if(hasLine()){
        int line_start = start;
        int line_end = count;
        std::string word = "";
        while(start < line_end){
            if(start == bufferSize){
                start = 0;
            }
            if(buffer[start] == '\n'){
                mtx.unlock();
                word += buffer[start];
                start++;
                return word;
            }else{
                word += buffer[start];
                start++;
            }
        }
    }
    mtx.unlock();
    
    return word;
};

