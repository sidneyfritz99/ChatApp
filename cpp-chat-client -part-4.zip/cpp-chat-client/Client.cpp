/**
 * Author: Sidney Fritz, Matthias Hoffman
 */

#include "Client.h"
#include "Application.h"
#include "vusocket.h"
#include <iostream>
#include <string>


void Client::tick() {
    std::string send_val;
    //std::cout << stdinBuffer.hasLine() << std::endl;
    if(stdinBuffer.hasLine()){
        std::string line;
        line = stdinBuffer.readLine();
        if(line.length() > 0){
            if(line.at(0) == '!' || line.at(0) == '@'){
                if(line.at(0) == '!'){
                    if(line == "!who\n"){
                        send(sockFR, "WHO\n", 4, 0);
                        std::cout << "SENT: " << "WHO\n";
                    }
                    else if(line == "!quit\n"){
                        std::cout << "READ: " << "!quit" << std::endl;
                        stopApplication();
                        if(isStopped()){
                            return;
                        }
                    }
                }
                else if(line.at(0) == '@'){
                    std::string command = "SEND ";
                    std::string message = line;
                    message.replace(0, 1, "") + "\n";
                    send_val = command + message;
                    send(sockFR, send_val.c_str(), send_val.length(), 0);
                    std::cout << "SENT: " << send_val << std::endl;
                }
            }
        }
    }
    if(socketBuffer.hasLine()){
        std::string line;
        line = socketBuffer.readLine();
        if(line.length() > 0){
            std::cout << "RECEIVED: " << line << "> Press Enter to Continue" << std::endl;
        }
        //return;
    }
}

int Client::readFromStdin(){
    if(!stdinBuffer.hasLine()){
        //ask the user for input such as a message or command
        std::cout << "INPUT?" << std::endl;
        char in[4096];
        std::string in_string;
        std::getline(std::cin, in_string);
        in_string = in_string + '\n';
        stdinBuffer.writeChars(in_string.c_str(), in_string.length());
        std::cin.ignore();
        std::cin.sync();
        std::cin.clear();
        memset(&in, 0, sizeof(in));
    }
    return 1;
}

int Client::readFromSocket(){
    char rec_buffer[4096];
    ssize_t retval = recv(sockFR, rec_buffer, sizeof(rec_buffer), 0);
    int x = (unsigned)strlen(rec_buffer);
    if(retval){
        socketBuffer.writeChars(rec_buffer, x);
    }
    memset(&rec_buffer, 0, sizeof(rec_buffer));
    return 1;
}

void Client::closeSocket(){
    sock_close(sock);
    sock_quit();
    std::cout << "Socket quit" << std::endl;
}

void Client::createSocketAndLogIn() {
    sock_init();
    int status;
    struct addrinfo hints;
    struct addrinfo *servinfo;  // will point to the results

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_protocol = IPPROTO_TCP;     // fill in my IP for me

    if ((status = getaddrinfo("52.58.97.202", "5378", &hints, &servinfo)) > 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        exit(1);
    } else {
        std::cout << "Connection Success\n";
        bool in_use = true;
        while (in_use) {
            sockFR = socket(servinfo->ai_family, servinfo->ai_socktype, 0);
            if (connect(sockFR, servinfo->ai_addr, servinfo->ai_addrlen) < 0) {
                std::cout << "error";
            }
            std::string user;
            std::cout << "Please enter a username:" << std::endl;
            std::getline(std::cin, user);

            std::string message = "HELLO-FROM " + user + "\n";

            const char *buffer = message.c_str();

            if ((send(sockFR, buffer, strlen(buffer), 0)) < 0) {
                fprintf(stderr, "error in socket send\n");
            }

            char buf[1024];

            ssize_t retval = recv(sockFR, buf, sizeof(buf), 0);
            if (retval <= 0) {
                std::cout << "error" << "\n";
            } else {
                std::cout << buf;
                if((std::string)buf != "IN-USE\n" && (std::string)buf != "BUSY\n"){
                    break;
                }
                else if((std::string)buf == "IN_USE\n"){
                    std::cout << "That username is in use";
                }
                else if((std::string)buf == "BUSY\n"){
                    std::cout << "Server Busy";
                }

            }
            memset(&buf, 0, sizeof(buf));
            memset(&buffer, 0, sizeof(buffer));
            std::cin.clear();
            std::cin.sync();
        }
        freeaddrinfo(servinfo); // free the linked-list
    }

}
